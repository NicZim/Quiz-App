//
//  QuestionBank.swift
//  realQuiz
//
//  Created by Nic Zimbelman on 5/10/19.
//  Copyright © 2019 Nic Zimbelman. All rights reserved.
//

import Foundation


class QuestionBank{
    
    var list = [Question]()
    
    init () {
        list.append(Question(questionText: "What is 2 + 2?", choiceA: "5", choiceB: "1421241242212312313222", choiceC: "4", choiceD: "6", answer: 3))
        list.append(Question(questionText: "What is 3 + 3?", choiceA: "1232", choiceB: "49", choiceC: "6", choiceD: "45", answer: 3))
        list.append(Question(questionText: "What is 4 + 4?", choiceA: "56", choiceB: "8", choiceC: "9", choiceD: "11", answer: 2))
        list.append(Question(questionText: "What is 5 + 5?", choiceA: "123", choiceB: "11", choiceC: "12222", choiceD: "10", answer: 4))
        list.append(Question(questionText: "How many people are in the U.S.?", choiceA: "12", choiceB: "1111", choiceC: "Fourty Two", choiceD: "325,145,963", answer: 4))
        list.append(Question(questionText: "What is the most expensive car?", choiceA: "BUGATTI", choiceB: "honda civic", choiceC: "tesla model S", choiceD: "Koenigsegg Trevita", answer: 4))
        list.append(Question(questionText: "What is the largest esports prize pool?", choiceA: "$1000", choiceB: "$1,000,000", choiceC: "$25,532,177", choiceD: "$100,000,000", answer: 3))
        list.append(Question(questionText: "Where is the next olympics?", choiceA: "Japan", choiceB: "China", choiceC: "North Korea", choiceD: "Russia", answer: 1))
        list.append(Question(questionText: "What is the top trending coding language?", choiceA: "C#", choiceB: "JavaScript", choiceC: "C++", choiceD: "Java", answer: 1))
        list.append(Question(questionText: "What language am I writing this code in?", choiceA: "Java", choiceB: "Swift", choiceC: "Kotlin", choiceD: "HTML", answer: 2))
        
    }
    
}
