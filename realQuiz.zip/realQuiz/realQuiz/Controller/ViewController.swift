//
//  ViewController.swift
//  realQuiz
//
//  Created by Nic Zimbelman on 5/9/19.
//  Copyright © 2019 Nic Zimbelman. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var questionAmount: UILabel!
    @IBOutlet weak var questionScore: UILabel!
    @IBOutlet weak var progressView: UIView!
    @IBOutlet weak var questionLabel: UILabel!
    
    
    @IBOutlet weak var buttonA: UIButton!
    @IBOutlet weak var buttonB: UIButton!
    @IBOutlet weak var buttonC: UIButton!
    @IBOutlet weak var buttonD: UIButton!
    
    let allQuestions = QuestionBank()
    var questionNumber: Int = 0
    var score: Int = 0
    var selectedAnswer: Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        updateQuestion()
        updateUI()
        
    }

    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    
    
    
    @IBAction func answerPressed(_ sender: UIButton) {
        
        if sender.tag == selectedAnswer {
            print("Correct!!")
            score += 1
        }else{
            print("Wrong!!")
        }
        
        
        questionNumber += 1
        updateQuestion()
        
        
        
        
    }
    
    func updateQuestion(){
        
        
        
        
        if questionNumber <= allQuestions.list.count - 1{
            
            questionLabel.text = allQuestions.list[questionNumber].question
            buttonA.setTitle(allQuestions.list[questionNumber].optionA, for: UIControl.State.normal)
            buttonB.setTitle(allQuestions.list[questionNumber].optionB, for: UIControl.State.normal)
            buttonC.setTitle(allQuestions.list[questionNumber].optionC, for: UIControl.State.normal)
            buttonD.setTitle(allQuestions.list[questionNumber].optionD, for: UIControl.State.normal)
            selectedAnswer = allQuestions.list[questionNumber].correctAnswer
           
        }else {
            let alert = UIAlertController(title: "Nice", message: "End of the quiz, would you like to start over?", preferredStyle: .alert)
            let restartAction = UIAlertAction(title: "Restart", style: .default, handler: {action in self.restartQuiz()})
            alert.addAction(restartAction)
            present(alert, animated: true, completion: nil)
        }
        
        updateUI()
        
    }
    
    func updateUI(){
     
        questionScore.text = "Score: \(score)"
        questionAmount.text = "\(questionNumber + 1)/\(allQuestions.list.count)"
        progressView.frame.size.width = (view.frame.size.width / CGFloat(allQuestions.list.count)) * CGFloat(questionNumber + 1)
        
    }
    
    func restartQuiz(){
        
        score = 0
        questionNumber = 0
        updateQuestion()
        
    }
}

